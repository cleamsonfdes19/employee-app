import express from 'express';

const app = express();
const port = 5000;

app.use(express.json());

// A simple route
app.get('/', (req, res) => {
  res.send('Hello, Employee Management Backend!');
});

app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
