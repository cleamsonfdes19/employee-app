import { Request, Response } from 'express';
import { Employee } from '../database'; // Import Employee model

// Get all employees
export const getAllEmployees = async (req: Request, res: Response): Promise<void> => {
  try {
    const employees = await Employee.findAll(); // Fetch all employees
    res.status(200).json(employees); // Respond with the employees list
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch employees' });
  }
};

// Create a new employee
export const createEmployee = async (req: Request, res: Response): Promise<void> => {
  try {
    const { name } = req.body;  // Extract name from request body
    if (!name) {
      res.status(400).json({ error: 'Employee name is required' });
      return;
    }
    const newEmployee = await Employee.create({ name });  // Create a new employee
    res.status(201).json(newEmployee);  // Respond with the newly created employee
  } catch (error) {
    res.status(500).json({ error: 'Failed to create employee' });
  }
};

// Get a specific employee by ID
export const getEmployeeById = async (req: Request, res: Response): Promise<void> => {
  try {
    const { id } = req.params;
    const employee = await Employee.findByPk(id); // Find employee by primary key
    if (!employee) {
      res.status(404).json({ error: 'Employee not found' });
      return;
    }
    res.status(200).json(employee); // Respond with employee details
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch employee' });
  }
};

// Update an employee's details
export const updateEmployee = async (req: Request, res: Response): Promise<void> => {
  try {
    const { id } = req.params;
    const { name } = req.body;  // Extract updated name from request body
    if (!name) {
      res.status(400).json({ error: 'Employee name is required' });
      return;
    }
    const employee = await Employee.findByPk(id);  // Find employee by primary key
    if (!employee) {
      res.status(404).json({ error: 'Employee not found' });
      return;
    }
    employee.name = name;  // Update employee's name
    await employee.save();  // Save updated employee data
    res.status(200).json(employee);  // Respond with updated employee details
  } catch (error) {
    res.status(500).json({ error: 'Failed to update employee' });
  }
};

// Delete an employee
export const deleteEmployee = async (req: Request, res: Response): Promise<void> => {
  try {
    const { id } = req.params;  // Extract employee ID from URL parameter
    const employee = await Employee.findByPk(id);  // Find employee by primary key
    if (!employee) {
      res.status(404).json({ error: 'Employee not found' });
      return;
    }
    await employee.destroy();  // Delete employee from the database
    res.status(200).json({ message: 'Employee deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete employee' });
  }
};
