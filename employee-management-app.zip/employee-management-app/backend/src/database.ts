import { Sequelize, DataTypes, Model, Optional } from 'sequelize';

// Set up Sequelize connection to SQLite
const sequelize = new Sequelize({
  dialect: 'sqlite',
  storage: './database.sqlite',  // SQLite database file
});

// Define an interface for the Employee model's attributes
interface EmployeeAttributes {
  id: number;
  name: string;
}

// Define an interface for creating new employees (without the id)
interface EmployeeCreationAttributes extends Optional<EmployeeAttributes, 'id'> {}

class Employee extends Model<EmployeeAttributes, EmployeeCreationAttributes> implements EmployeeAttributes {
  public id!: number;
  public name!: string;
}

// Initialize the model with the sequelize instance and define its attributes
Employee.init(
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    name: {
      type: DataTypes.STRING,
      allowNull: false,  // Ensure that name is not empty
    },
  },
  {
    sequelize,
    modelName: 'Employee',
    tableName: 'employees',
    timestamps: false,  // Optional, add if you don't want automatic timestamp fields
  }
);

// Initialize the database and sync models
const initDatabase = async () => {
  try {
    await sequelize.sync(); // Sync the model to create the table if not exists
    console.log('Database synced successfully');
  } catch (error) {
    console.error('Error syncing database:', error);
  }
};

export { sequelize, Employee, initDatabase };
