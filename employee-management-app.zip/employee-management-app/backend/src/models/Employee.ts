import { DataTypes, Model } from 'sequelize';
import sequelize from '../db';  // Import Sequelize instance

// Define Employee model
class Employee extends Model {
  public id!: number;
  public name!: string;
}

Employee.init(
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    name: {
      type: DataTypes.STRING,
      allowNull: false,
    },
  },
  {
    sequelize,
    modelName: 'Employee',
    tableName: 'employees',
    timestamps: false,  // Disable automatic createdAt/updatedAt columns
  }
);

export default Employee;
