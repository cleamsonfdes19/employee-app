import express from 'express';
import {
  getAllEmployees,
  createEmployee,
  getEmployeeById,
  updateEmployee,
  deleteEmployee,
} from '../controllers/employeeController';

const router = express.Router();

// Define routes for employees
router.get('/employees', getAllEmployees);  // Get all employees
router.post('/employees', createEmployee);  // Create a new employee
router.get('/employees/:id', getEmployeeById);  // Get employee by ID
router.put('/employees/:id', updateEmployee);  // Update employee details
router.delete('/employees/:id', deleteEmployee);  // Delete employee

export default router;
