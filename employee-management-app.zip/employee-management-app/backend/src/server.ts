import express from 'express';
import cors from 'cors';
import { initDatabase } from './database';  // Initialize the database
import employeeRoutes from './routes/employeeRoutes';  // Import employee routes

const app = express();
const PORT = 5000;

// Middleware
app.use(cors());
app.use(express.json());

// Routes
app.use('/api', employeeRoutes);  // Use employee routes

// Initialize database and start server
initDatabase().then(() => {
  app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}).catch((error) => {
  console.error('Error starting the server:', error);
});
