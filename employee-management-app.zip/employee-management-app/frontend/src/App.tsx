import React, { useState, useEffect } from 'react';
import axios from 'axios';

const App: React.FC = () => {
  const [employees, setEmployees] = useState<any[]>([]);
  const [name, setName] = useState<string>('');
  const [error, setError] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);

  // Fetch all employees
  const getEmployees = async () => {
    setLoading(true);
    try {
      const response = await axios.get('http://localhost:5000/api/employees');
      setEmployees(response.data);
    } catch (error) {
      setError('Error fetching employees');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    getEmployees();
  }, []);

  // Add a new employee
  const addEmployee = async () => {
    if (!name.trim()) {
      setError('Please provide a valid employee name');
      return;
    }

    setLoading(true);
    try {
      const response = await axios.post('http://localhost:5000/api/employees', { name });
      setEmployees((prev) => [...prev, response.data]); // Add the new employee to the list
      setName(''); // Clear the input field
    } catch (error) {
      setError('Error adding employee');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <h1>Employee Management</h1>

      {error && <p style={{ color: 'red' }}>{error}</p>} {/* Show error message */}
      
      <input
        type="text"
        placeholder="Enter employee name"
        value={name}
        onChange={(e) => {
          setName(e.target.value);
          setError(''); // Clear error message as user starts typing
        }}
      />
      <button onClick={addEmployee} disabled={loading}>Add Employee</button>

      {loading && <p>Loading...</p>} {/* Show loading state */}
      
      <h2>Employee List</h2>
      <ul>
        {employees.map((employee) => (
          <li key={employee.id}>{employee.name}</li>
        ))}
      </ul>
    </div>
  );
};

export default App;
