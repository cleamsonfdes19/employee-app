import React, { useState, useEffect } from "react";
import { Employee } from "../types";

interface EmployeeFormProps {
  onSave: (employee: { name: string }) => void;
  selectedEmployee: Employee | null;
}

const EmployeeForm: React.FC<EmployeeFormProps> = ({ onSave, selectedEmployee }) => {
  const [name, setName] = useState("");

  useEffect(() => {
    if (selectedEmployee) {
      setName(selectedEmployee.name);
    }
  }, [selectedEmployee]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({ name });
    setName("");
  };

  return (
    <form onSubmit={handleSubmit}>
      <input
        type="text"
        value={name}
        onChange={(e) => setName(e.target.value)}
        placeholder="Employee Name"
      />
      <button type="submit">Save</button>
    </form>
  );
};

export default EmployeeForm;
