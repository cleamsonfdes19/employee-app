import React from "react";
import { Employee } from "../types";

interface EmployeeListProps {
  employees: Employee[];
  onSelect: (employee: Employee) => void;
  onDelete: (id: number) => void;
}

const EmployeeList: React.FC<EmployeeListProps> = ({ employees, onSelect, onDelete }) => {
  return (
    <div>
      {employees.map((employee) => (
        <div key={employee.id}>
          <span>{employee.name}</span>
          <button onClick={() => onSelect(employee)}>Edit</button>
          <button onClick={() => onDelete(employee.id)}>Delete</button>
        </div>
      ))}
    </div>
  );
};

export default EmployeeList;
